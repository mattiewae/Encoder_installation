﻿# -------------------------------------------------------------
# Uncomment 'Set-ExecutionPolicy RemoteSigned' en voer uit (F5) 
# -------------------------------------------------------------
#Set-ExecutionPolicy RemoteSigned

# Check of E-schijf bestaat, indien niet, maak folder aan op C-schijf.
# Premiere project wordt altijd ge-exporteerd naar C:\Temp, daar worden alle bewerkingen gedaan. 
# De uiteindelijk mp4 file wordt gekopieerd naar E/C:\AdobeExport.

# variabelen
$Temp = 'C:\Temp';
$checkLocation = Test-Path 'E:\AdobeExport';
$script:ffmpeg = "C:\encoder\ffmpeg\bin\ffmpeg.exe";
$script:mp4box = "C:\encoder\mp4box\MP4box.exe";
$script:qtaacenc = "C:\encoder\qtaacenc\qtaacenc.exe";
$script:oldvid = Get-ChildItem *.mxf 
$script:newvid = [io.path]::ChangeExtension($oldvid.FullName, '.mp4')


Set-Location $Temp;

# # MXF to MP4 no audio
# CRF: 0 is lossless, 23 is default, and 51 is worst possible
function MxfToMp4() {
$oldvids = Get-ChildItem *.mxf #-Recurse
foreach ($oldvid in $oldvids) {
    #$Script:newvid = [io.path]::ChangeExtension($oldvid.FullName, '.mp4') 
    &$script:ffmpeg -i $oldvid.FullName -an -pix_fmt yuv420p -c:v libx264 -crf 23 -profile:v high -level 4.1 -aspect 16:9 -flags +ildct+ilme -x264opts weightp=0:tff=1 $script:newvid -y;
}
}

# # Haal de 8 channels uit MXF -> TODO: Check op aantal kanalen. 
# Do while ipv foreach
function MxfExtractor() {
$mxf = Get-ChildItem *.mxf
for($i=1
     $i -le 8
     $i++){
       &$script:ffmpeg -i $mxf -map 0:$i -acodec: copy -vn mono$i.wav -y}
}

# # 2xmono > stereo
function Mono2Stereo() {
&$script:ffmpeg -i mono1.wav -i mono2.wav -filter_complex "[0:a][1:a]amerge=inputs=2[aout]" -map "[aout]" stereo1.wav  -y
&$script:ffmpeg -i mono3.wav -i mono4.wav -filter_complex "[0:a][1:a]amerge=inputs=2[aout]" -map "[aout]" stereo2.wav -y
&$script:ffmpeg -i mono5.wav -i mono6.wav -filter_complex "[0:a][1:a]amerge=inputs=2[aout]" -map "[aout]" stereo3.wav -y
&$script:ffmpeg -i mono7.wav -i mono8.wav -filter_complex "[0:a][1:a]amerge=inputs=2[aout]" -map "[aout]" stereo4.wav -y
}

function Wave2aac()
{
    &$script:qtaacenc .\stereo1.wav stereo1.m4a
    &$script:qtaacenc .\stereo2.wav stereo2.m4a
    &$script:qtaacenc .\stereo3.wav stereo3.m4a
    &$script:qtaacenc .\stereo4.wav stereo4.m4a
}

function Mp4Mix()
{
    #$argu = '-add stereo1.m4a -add stereo2.m4a -add stereo3.m4a -add stereo4.m4a';
    & $Script:mp4box -add stereo1.m4a -add stereo2.m4a -add stereo3.m4a -add stereo4.m4a $script:newvid
    
}

# Wachten op input voor af te sluiten
function Wait-KeyPress($prompt='Druk op een toets ...!') {
	Write-Host $prompt 	
	do {
		Start-Sleep -milliseconds 100
	} until ($Host.UI.RawUI.KeyAvailable)

	$Host.UI.RawUI.FlushInputBuffer()
}

MxfToMp4

MxfExtractor

Mono2Stereo

Wave2aac

Mp4Mix

#Wait-KeyPress   